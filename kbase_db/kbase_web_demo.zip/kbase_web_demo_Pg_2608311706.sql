--
-- PostgreSQL database dump
--

\restrict OOjHtfBg1kN2IlPhiH7N8RIePUwCL6aHI9zRuDBQp2828CDR5fCwhbtk4cJdp4F

-- Dumped from database version 18.6 (Ubuntu 18.6-1.pgdg24.04+2)
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: kbase_web_demo; Type: DATABASE; Schema: -; Owner: kbase
--

CREATE DATABASE kbase_web_demo WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'uk_UA.UTF-8';


ALTER DATABASE kbase_web_demo OWNER TO kbase;

\unrestrict OOjHtfBg1kN2IlPhiH7N8RIePUwCL6aHI9zRuDBQp2828CDR5fCwhbtk4cJdp4F
\connect kbase_web_demo
\restrict OOjHtfBg1kN2IlPhiH7N8RIePUwCL6aHI9zRuDBQp2828CDR5fCwhbtk4cJdp4F

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: kbase; Type: SCHEMA; Schema: -; Owner: kbase
--

CREATE SCHEMA kbase;


ALTER SCHEMA kbase OWNER TO kbase;

--
-- Name: ltree; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA ltree;


ALTER SCHEMA ltree OWNER TO postgres;

--
-- Name: ltree; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS ltree WITH SCHEMA ltree;


--
-- Name: EXTENSION ltree; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION ltree IS 'data type for hierarchical tree-like structures';


--
-- Name: trg_section_set_path(); Type: FUNCTION; Schema: kbase; Owner: postgres
--

CREATE FUNCTION kbase.trg_section_set_path() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
-- Функція для автоматичного розрахунку шляху при INSERT
BEGIN
    IF NEW.parent_id IS NULL THEN
        NEW.section_path := NEW.id::text::ltree.ltree;
    ELSE
        SELECT parent.section_path || NEW.id::text::ltree.ltree
        INTO NEW.section_path
        FROM kbase.sections parent
        WHERE parent.id = NEW.parent_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION kbase.trg_section_set_path() OWNER TO postgres;

--
-- Name: trg_section_update_date_modified_info(); Type: FUNCTION; Schema: kbase; Owner: postgres
--

CREATE FUNCTION kbase.trg_section_update_date_modified_info() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE sections
    SET date_modified_info = now()
    WHERE id = COALESCE(NEW.section_id, OLD.section_id);
    RETURN COALESCE(NEW, OLD);
END;
$$;


ALTER FUNCTION kbase.trg_section_update_date_modified_info() OWNER TO postgres;

--
-- Name: trg_section_update_path_on_move(); Type: FUNCTION; Schema: kbase; Owner: postgres
--

CREATE FUNCTION kbase.trg_section_update_path_on_move() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
-- Функція для оновлення шляхів при зміні parent_id (переміщення гілки)
DECLARE
    old_path ltree.ltree;
    new_path ltree.ltree;
BEGIN
    -- Якщо parent_id не змінився — нічого не робимо
    IF OLD.parent_id IS NOT DISTINCT FROM NEW.parent_id THEN
        RETURN NEW;
    END IF;

    -- Зберігаємо старий шлях
    old_path := OLD.section_path;

    -- Розраховуємо новий шлях (як при INSERT)
    IF NEW.parent_id IS NULL THEN
        new_path := NEW.id::text::ltree.ltree;
    ELSE
        SELECT parent.section_path || NEW.id::text::ltree.ltree
        INTO new_path
        FROM kbase.sections parent
        WHERE parent.id = NEW.parent_id;
    END IF;

    -- Оновлюємо поточний рядок
    NEW.section_path := new_path;

    -- Оновлюємо ВСІХ нащадків (рекурсивно через ltree)
    UPDATE kbase.sections
    SET section_path = new_path || subpath(section_path, nlevel(old_path))
    WHERE section_path <@ old_path
      AND id != NEW.id;

    RETURN NEW;
END;
$$;


ALTER FUNCTION kbase.trg_section_update_path_on_move() OWNER TO postgres;

--
-- Name: seq_groups; Type: SEQUENCE; Schema: kbase; Owner: postgres
--

CREATE SEQUENCE kbase.seq_groups
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_groups OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: groups; Type: TABLE; Schema: kbase; Owner: postgres
--

CREATE TABLE kbase.groups (
    id bigint DEFAULT nextval('kbase.seq_groups'::regclass) NOT NULL,
    name character varying NOT NULL,
    descr character varying,
    is_active boolean DEFAULT true NOT NULL,
    date_created timestamp with time zone DEFAULT now() NOT NULL,
    date_modified timestamp with time zone DEFAULT now() NOT NULL,
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.groups OWNER TO postgres;

--
-- Name: seq_icons; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_icons
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_icons OWNER TO kbase;

--
-- Name: icons; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.icons (
    id bigint DEFAULT nextval('kbase.seq_icons'::regclass) NOT NULL,
    parent_id bigint NOT NULL,
    name character varying(50) NOT NULL,
    descr character varying(50),
    image bytea,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.icons OWNER TO kbase;

--
-- Name: log_types; Type: TABLE; Schema: kbase; Owner: postgres
--

CREATE TABLE kbase.log_types (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(200),
    date_created timestamp with time zone DEFAULT now() NOT NULL,
    date_modified timestamp with time zone DEFAULT now() NOT NULL,
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.log_types OWNER TO postgres;

--
-- Name: log_types_id_seq; Type: SEQUENCE; Schema: kbase; Owner: postgres
--

CREATE SEQUENCE kbase.log_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.log_types_id_seq OWNER TO postgres;

--
-- Name: log_types_id_seq; Type: SEQUENCE OWNED BY; Schema: kbase; Owner: postgres
--

ALTER SEQUENCE kbase.log_types_id_seq OWNED BY kbase.log_types.id;


--
-- Name: seq_logs; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_logs
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_logs OWNER TO kbase;

--
-- Name: logs; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.logs (
    id bigint DEFAULT nextval('kbase.seq_logs'::regclass) NOT NULL,
    text character varying(255),
    date_created timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    log_type_id bigint
);


ALTER TABLE kbase.logs OWNER TO kbase;

--
-- Name: TABLE logs; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.logs IS 'Various logs';


--
-- Name: seq_privileges; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_privileges
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_privileges OWNER TO kbase;

--
-- Name: privileges; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.privileges (
    id bigint DEFAULT nextval('kbase.seq_privileges'::regclass) NOT NULL,
    name character varying(50) NOT NULL,
    descr character varying(200),
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint DEFAULT 1,
    user_id_modified bigint DEFAULT 1
);


ALTER TABLE kbase.privileges OWNER TO kbase;

--
-- Name: seq_refresh_tokens; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_refresh_tokens
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_refresh_tokens OWNER TO kbase;

--
-- Name: refresh_tokens; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.refresh_tokens (
    id bigint DEFAULT nextval('kbase.seq_refresh_tokens'::regclass) NOT NULL,
    token character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    expiry_date timestamp with time zone NOT NULL
);


ALTER TABLE kbase.refresh_tokens OWNER TO kbase;

--
-- Name: role_privileges; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.role_privileges (
    role_id bigint NOT NULL,
    privilege_id bigint NOT NULL,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint DEFAULT 1,
    user_id_modified bigint DEFAULT 1
);


ALTER TABLE kbase.role_privileges OWNER TO kbase;

--
-- Name: seq_roles; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_roles
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_roles OWNER TO kbase;

--
-- Name: roles; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.roles (
    id bigint DEFAULT nextval('kbase.seq_roles'::regclass) NOT NULL,
    name character varying(50) NOT NULL,
    descr character varying(200),
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint DEFAULT 1,
    user_id_modified bigint DEFAULT 1
);


ALTER TABLE kbase.roles OWNER TO kbase;

--
-- Name: seq_section_categories; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_section_categories
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_categories OWNER TO kbase;

--
-- Name: section_categories; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_categories (
    id bigint DEFAULT nextval('kbase.seq_section_categories'::regclass) NOT NULL,
    parent_id bigint,
    name character varying(255) NOT NULL,
    descr character varying(500),
    icon_id bigint,
    template_id bigint,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.section_categories OWNER TO kbase;

--
-- Name: TABLE section_categories; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.section_categories IS 'Категорії Розділів у вигляді дерева';


--
-- Name: COLUMN section_categories.parent_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_categories.parent_id IS 'Батьківська категорія';


--
-- Name: COLUMN section_categories.icon_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_categories.icon_id IS 'Іконка категорії';


--
-- Name: COLUMN section_categories.template_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_categories.template_id IS 'Шаблон для розділів цієї категорії';


--
-- Name: seq_section_dictionaries; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_section_dictionaries
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_dictionaries OWNER TO kbase;

--
-- Name: section_dictionaries; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_dictionaries (
    id bigint DEFAULT nextval('kbase.seq_section_dictionaries'::regclass) NOT NULL,
    section_id bigint NOT NULL,
    type_id smallint NOT NULL,
    name character varying(255) NOT NULL,
    value text,
    descr character varying(500),
    rating integer DEFAULT 0 NOT NULL,
    reverse smallint DEFAULT 0 NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL,
    CONSTRAINT section_dictionaries_reverse_check CHECK ((reverse = ANY (ARRAY[0, 1]))),
    CONSTRAINT section_dictionaries_status_check CHECK ((status = ANY (ARRAY[0, 1]))),
    CONSTRAINT section_dictionaries_type_id_check CHECK ((type_id = ANY (ARRAY[1, 2, 3])))
);


ALTER TABLE kbase.section_dictionaries OWNER TO kbase;

--
-- Name: TABLE section_dictionaries; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.section_dictionaries IS 'Словники для навчання';


--
-- Name: COLUMN section_dictionaries.type_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_dictionaries.type_id IS 'Тип інформації: 1 - word, 2 - phrase, 3 - text';


--
-- Name: COLUMN section_dictionaries.rating; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_dictionaries.rating IS 'Рейтинг: як часто показувати при навчанні';


--
-- Name: COLUMN section_dictionaries.reverse; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_dictionaries.reverse IS '1 - показувати в зворотньому напрямку';


--
-- Name: COLUMN section_dictionaries.status; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_dictionaries.status IS '0 - не включати в навчання, 1 - включати';


--
-- Name: seq_section_document_info_block_components_binary; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_section_document_info_block_components_binary
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_document_info_block_components_binary OWNER TO kbase;

--
-- Name: section_document_info_block_components_binary; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_document_info_block_components_binary (
    id bigint DEFAULT nextval('kbase.seq_section_document_info_block_components_binary'::regclass) NOT NULL,
    section_document_info_block_header_id bigint CONSTRAINT section_document_info_block_section_document_info_bloc_not_null NOT NULL,
    section_document_info_block_type_component_id bigint CONSTRAINT section_document_info_bloc_section_document_info_bloc_not_null1 NOT NULL,
    storage_type smallint DEFAULT 1 CONSTRAINT section_document_info_block_components_bi_storage_type_not_null NOT NULL,
    value bytea,
    file_path character varying(500),
    file_size bigint,
    mime_type character varying(100),
    original_filename character varying(255),
    checksum character varying(64),
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint CONSTRAINT section_document_info_block_components_user_id_created_not_null NOT NULL,
    user_id_modified bigint CONSTRAINT section_document_info_block_component_user_id_modified_not_null NOT NULL,
    CONSTRAINT chk_storage_data_consistency CHECK ((((storage_type = 1) AND (value IS NOT NULL) AND (file_path IS NULL)) OR ((storage_type = ANY (ARRAY[2, 3])) AND (file_path IS NOT NULL) AND (value IS NULL)))),
    CONSTRAINT chk_storage_type CHECK ((storage_type = ANY (ARRAY[1, 2, 3])))
);


ALTER TABLE kbase.section_document_info_block_components_binary OWNER TO kbase;

--
-- Name: TABLE section_document_info_block_components_binary; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.section_document_info_block_components_binary IS 'Компоненти типів 2 - картинка, 3 - файл. Гібридне зберігання: 1=DB(bytea), 2=FS(path), 3=S3(key)';


--
-- Name: COLUMN section_document_info_block_components_binary.section_document_info_block_header_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_binary.section_document_info_block_header_id IS 'Заголовок інфо блоку';


--
-- Name: COLUMN section_document_info_block_components_binary.section_document_info_block_type_component_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_binary.section_document_info_block_type_component_id IS 'Тип компонента';


--
-- Name: COLUMN section_document_info_block_components_binary.storage_type; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_binary.storage_type IS 'Тип сховища: 1=DB(bytea), 2=FileSystem(path), 3=S3(key)';


--
-- Name: COLUMN section_document_info_block_components_binary.value; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_binary.value IS 'Бінарні дані (тільки для storage_type=1)';


--
-- Name: COLUMN section_document_info_block_components_binary.file_path; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_binary.file_path IS 'Шлях на FS або S3 object key (для storage_type=2,3)';


--
-- Name: COLUMN section_document_info_block_components_binary.file_size; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_binary.file_size IS 'Розмір файлу у байтах';


--
-- Name: COLUMN section_document_info_block_components_binary.mime_type; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_binary.mime_type IS 'MIME тип: image/png, application/pdf, ...';


--
-- Name: COLUMN section_document_info_block_components_binary.original_filename; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_binary.original_filename IS 'Оригінальна назва файлу при завантаженні';


--
-- Name: COLUMN section_document_info_block_components_binary.checksum; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_binary.checksum IS 'SHA-256 hex для дедуплікації та перевірки цілісності';


--
-- Name: seq_section_document_info_block_components_number; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_section_document_info_block_components_number
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_document_info_block_components_number OWNER TO kbase;

--
-- Name: section_document_info_block_components_number; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_document_info_block_components_number (
    id bigint DEFAULT nextval('kbase.seq_section_document_info_block_components_number'::regclass) NOT NULL,
    section_document_info_block_header_id bigint CONSTRAINT section_document_info_bloc_section_document_info_bloc_not_null2 NOT NULL,
    section_document_info_block_type_component_id bigint CONSTRAINT section_document_info_bloc_section_document_info_bloc_not_null3 NOT NULL,
    value bigint,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint CONSTRAINT section_document_info_block_component_user_id_created_not_null1 NOT NULL,
    user_id_modified bigint CONSTRAINT section_document_info_block_componen_user_id_modified_not_null1 NOT NULL
);


ALTER TABLE kbase.section_document_info_block_components_number OWNER TO kbase;

--
-- Name: TABLE section_document_info_block_components_number; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.section_document_info_block_components_number IS 'Компоненти типів 4 - ціле число, 5 - логічне значення';


--
-- Name: COLUMN section_document_info_block_components_number.section_document_info_block_header_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_number.section_document_info_block_header_id IS 'Заголовок інфо блоку';


--
-- Name: COLUMN section_document_info_block_components_number.section_document_info_block_type_component_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_number.section_document_info_block_type_component_id IS 'Тип компонента';


--
-- Name: seq_section_document_info_block_components_text; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_section_document_info_block_components_text
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_document_info_block_components_text OWNER TO kbase;

--
-- Name: section_document_info_block_components_text; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_document_info_block_components_text (
    id bigint DEFAULT nextval('kbase.seq_section_document_info_block_components_text'::regclass) NOT NULL,
    section_document_info_block_header_id bigint CONSTRAINT section_document_info_bloc_section_document_info_bloc_not_null4 NOT NULL,
    section_document_info_block_type_component_id bigint CONSTRAINT section_document_info_bloc_section_document_info_bloc_not_null5 NOT NULL,
    value text,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint CONSTRAINT section_document_info_block_component_user_id_created_not_null2 NOT NULL,
    user_id_modified bigint CONSTRAINT section_document_info_block_componen_user_id_modified_not_null2 NOT NULL
);


ALTER TABLE kbase.section_document_info_block_components_text OWNER TO kbase;

--
-- Name: TABLE section_document_info_block_components_text; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.section_document_info_block_components_text IS 'Компоненти типів 1 - текст';


--
-- Name: COLUMN section_document_info_block_components_text.section_document_info_block_header_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_text.section_document_info_block_header_id IS 'Заголовок інфо блоку';


--
-- Name: COLUMN section_document_info_block_components_text.section_document_info_block_type_component_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_components_text.section_document_info_block_type_component_id IS 'Тип компонента';


--
-- Name: seq_section_document_info_block_headers; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_section_document_info_block_headers
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_document_info_block_headers OWNER TO kbase;

--
-- Name: section_document_info_block_headers; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_document_info_block_headers (
    id bigint DEFAULT nextval('kbase.seq_section_document_info_block_headers'::regclass) NOT NULL,
    section_id bigint NOT NULL,
    section_document_info_block_type_id bigint CONSTRAINT section_document_info_bloc_section_document_info_bloc_not_null6 NOT NULL,
    section_document_info_block_style_id bigint,
    "position" bigint,
    name character varying(255),
    descr character varying(500),
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.section_document_info_block_headers OWNER TO kbase;

--
-- Name: TABLE section_document_info_block_headers; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.section_document_info_block_headers IS 'Заголовки інфо блоків Розділів';


--
-- Name: COLUMN section_document_info_block_headers.section_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_headers.section_id IS 'Розділ';


--
-- Name: COLUMN section_document_info_block_headers.section_document_info_block_type_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_headers.section_document_info_block_type_id IS 'Тип інформаційного блока';


--
-- Name: COLUMN section_document_info_block_headers.section_document_info_block_style_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_headers.section_document_info_block_style_id IS 'Стиль показу інфо блока';


--
-- Name: COLUMN section_document_info_block_headers."position"; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_headers."position" IS 'Позиція в списку інфо блоків Розділа';


--
-- Name: seq_section_document_info_block_styles; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_section_document_info_block_styles
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_document_info_block_styles OWNER TO kbase;

--
-- Name: section_document_info_block_styles; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_document_info_block_styles (
    id bigint DEFAULT nextval('kbase.seq_section_document_info_block_styles'::regclass) NOT NULL,
    parent_id bigint,
    name character varying(255) NOT NULL,
    descr character varying(500),
    icon_id bigint,
    template_id bigint,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.section_document_info_block_styles OWNER TO kbase;

--
-- Name: TABLE section_document_info_block_styles; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.section_document_info_block_styles IS 'Стилі інфоблоків: шаблон та іконка для відображення';


--
-- Name: COLUMN section_document_info_block_styles.parent_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_styles.parent_id IS 'Батьківський стиль (для ієрархії)';


--
-- Name: COLUMN section_document_info_block_styles.icon_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_styles.icon_id IS 'Іконка стилю';


--
-- Name: COLUMN section_document_info_block_styles.template_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_styles.template_id IS 'Шаблон для рендерингу';


--
-- Name: seq_section_document_info_block_type; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_section_document_info_block_type
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_document_info_block_type OWNER TO kbase;

--
-- Name: section_document_info_block_type; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_document_info_block_type (
    id bigint DEFAULT nextval('kbase.seq_section_document_info_block_type'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    descr character varying(500),
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.section_document_info_block_type OWNER TO kbase;

--
-- Name: TABLE section_document_info_block_type; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.section_document_info_block_type IS 'Типи інфоблоків для документів';


--
-- Name: COLUMN section_document_info_block_type.name; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_type.name IS 'Назва типу інфоблоку';


--
-- Name: seq_section_document_info_block_type_components; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_section_document_info_block_type_components
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_document_info_block_type_components OWNER TO kbase;

--
-- Name: section_document_info_block_type_components; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_document_info_block_type_components (
    id bigint DEFAULT nextval('kbase.seq_section_document_info_block_type_components'::regclass) NOT NULL,
    section_document_info_block_type_id bigint CONSTRAINT section_document_info_bloc_section_document_info_bloc_not_null7 NOT NULL,
    name character varying(100) NOT NULL,
    descr character varying(500),
    component_type smallint CONSTRAINT section_document_info_block_type_compon_component_type_not_null NOT NULL,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint CONSTRAINT section_document_info_block_type_compo_user_id_created_not_null NOT NULL,
    user_id_modified bigint CONSTRAINT section_document_info_block_type_comp_user_id_modified_not_null NOT NULL,
    CONSTRAINT section_document_info_block_type_component_component_type_check CHECK ((component_type = ANY (ARRAY[1, 2, 3, 4, 5])))
);


ALTER TABLE kbase.section_document_info_block_type_components OWNER TO kbase;

--
-- Name: TABLE section_document_info_block_type_components; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.section_document_info_block_type_components IS 'Компоненти, з яких складається тип інфоблоку';


--
-- Name: COLUMN section_document_info_block_type_components.component_type; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_document_info_block_type_components.component_type IS 'Тип компонента: 1 - текст, 2 - картинка, 3 - файл, 4 - ціле число, 5 - логічне значення';


--
-- Name: seq_section_documents; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_section_documents
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_documents OWNER TO kbase;

--
-- Name: section_documents; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_documents (
    id bigint DEFAULT nextval('kbase.seq_section_documents'::regclass) NOT NULL,
    section_id bigint NOT NULL,
    body text,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.section_documents OWNER TO kbase;

--
-- Name: TABLE section_documents; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.section_documents IS 'Скомпільовані з інфо блоків документи';


--
-- Name: COLUMN section_documents.body; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.section_documents.body IS 'HTML/текст скомпільованого документа';


--
-- Name: section_group_access; Type: TABLE; Schema: kbase; Owner: postgres
--

CREATE TABLE kbase.section_group_access (
    section_id bigint NOT NULL,
    group_id bigint NOT NULL,
    access_level smallint DEFAULT 1 NOT NULL,
    is_inherited boolean DEFAULT false NOT NULL,
    date_created timestamp with time zone DEFAULT now() NOT NULL,
    date_modified timestamp with time zone DEFAULT now() NOT NULL,
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL,
    CONSTRAINT chk_section_group_access_level CHECK ((access_level = ANY (ARRAY[1, 2])))
);


ALTER TABLE kbase.section_group_access OWNER TO postgres;

--
-- Name: COLUMN section_group_access.access_level; Type: COMMENT; Schema: kbase; Owner: postgres
--

COMMENT ON COLUMN kbase.section_group_access.access_level IS 'Access level: 1 = view, 2 = edit';


--
-- Name: section_types; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.section_types (
    id bigint NOT NULL,
    name character varying(25) NOT NULL,
    descr character varying(100),
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint DEFAULT 1,
    user_id_modified bigint DEFAULT 1
);


ALTER TABLE kbase.section_types OWNER TO kbase;

--
-- Name: seq_sections; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_sections
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_sections OWNER TO kbase;

--
-- Name: sections; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.sections (
    id bigint DEFAULT nextval('kbase.seq_sections'::regclass) NOT NULL,
    parent_id bigint,
    name character varying(255) NOT NULL,
    descr character varying(255),
    section_type_id bigint NOT NULL,
    section_category_id bigint NOT NULL,
    section_category_id_dir bigint,
    section_category_id_def bigint,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    date_modified_info timestamp with time zone,
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL,
    section_path ltree.ltree
);


ALTER TABLE kbase.sections OWNER TO kbase;

--
-- Name: TABLE sections; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.sections IS 'Розділи Бази Знань у вигляді дерева';


--
-- Name: COLUMN sections.section_type_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.sections.section_type_id IS 'Тип інформації розділу: 1 - документ, 2 - словник, в перспективі 3 - Галерея';


--
-- Name: COLUMN sections.section_category_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.sections.section_category_id IS 'Категорія розділу (наприклад: Заявки-Закрита, Роботи, Документація)';


--
-- Name: COLUMN sections.section_category_id_dir; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.sections.section_category_id_dir IS 'Директорія, звідки будуть вибиратися категорії у підрозділах';


--
-- Name: COLUMN sections.section_category_id_def; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.sections.section_category_id_def IS 'Категорія за замовчуванням для підрозділів';


--
-- Name: COLUMN sections.date_modified_info; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.sections.date_modified_info IS 'Остання зміна інфоблоків';


--
-- Name: seq_section_group_access; Type: SEQUENCE; Schema: kbase; Owner: postgres
--

CREATE SEQUENCE kbase.seq_section_group_access
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_section_group_access OWNER TO postgres;

--
-- Name: seq_settings; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_settings
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_settings OWNER TO kbase;

--
-- Name: template_bodies; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.template_bodies (
    id bigint NOT NULL,
    template_id bigint NOT NULL,
    template_color_theme_id bigint NOT NULL,
    body text,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.template_bodies OWNER TO kbase;

--
-- Name: TABLE template_bodies; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.template_bodies IS 'Тіла шаблонів для кожної кольорової теми';


--
-- Name: COLUMN template_bodies.body; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.template_bodies.body IS 'HTML/текст тіла шаблону';


--
-- Name: seq_template_bodies; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_template_bodies
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_template_bodies OWNER TO kbase;

--
-- Name: seq_template_bodies; Type: SEQUENCE OWNED BY; Schema: kbase; Owner: kbase
--

ALTER SEQUENCE kbase.seq_template_bodies OWNED BY kbase.template_bodies.id;


--
-- Name: template_color_themes; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.template_color_themes (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    type character varying(10) NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL,
    CONSTRAINT template_color_themes_type_check CHECK (((type)::text = ANY (ARRAY[('light'::character varying)::text, ('dark'::character varying)::text])))
);


ALTER TABLE kbase.template_color_themes OWNER TO kbase;

--
-- Name: TABLE template_color_themes; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.template_color_themes IS 'Кольорові теми для шаблонів';


--
-- Name: COLUMN template_color_themes.type; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.template_color_themes.type IS 'Тип теми: light - світла, dark - темна';


--
-- Name: COLUMN template_color_themes.is_default; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.template_color_themes.is_default IS 'Теми за замовчуванням, повинна бути одна світла і одна темна';


--
-- Name: seq_template_color_themes; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_template_color_themes
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_template_color_themes OWNER TO kbase;

--
-- Name: seq_template_color_themes; Type: SEQUENCE OWNED BY; Schema: kbase; Owner: kbase
--

ALTER SEQUENCE kbase.seq_template_color_themes OWNED BY kbase.template_color_themes.id;


--
-- Name: template_files; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.template_files (
    id bigint NOT NULL,
    parent_id bigint,
    is_dir boolean DEFAULT false NOT NULL,
    is_reserved boolean DEFAULT false NOT NULL,
    file_type smallint NOT NULL,
    file_name character varying(255) NOT NULL,
    descr character varying(255),
    body text,
    body_bin bytea,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL,
    CONSTRAINT template_files_file_type_check CHECK ((file_type = ANY (ARRAY[1, 2, 3])))
);


ALTER TABLE kbase.template_files OWNER TO kbase;

--
-- Name: TABLE template_files; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.template_files IS 'Файли шаблонів (картинки, CSS, JS, бінарні) у вигляді дерева';


--
-- Name: COLUMN template_files.parent_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.template_files.parent_id IS 'Батьківська директорія';


--
-- Name: COLUMN template_files.is_dir; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.template_files.is_dir IS 'true - директорія, false - файл';


--
-- Name: COLUMN template_files.is_reserved; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.template_files.is_reserved IS 'Зарезервовані файли, ті що використовуються в шаблонах';


--
-- Name: COLUMN template_files.file_type; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.template_files.file_type IS 'Тип файлу: 1 - текстовий, 2 - картинка, 3 - бінарний';


--
-- Name: COLUMN template_files.body; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.template_files.body IS 'Вміст текстового файлу';


--
-- Name: COLUMN template_files.body_bin; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.template_files.body_bin IS 'Вміст бінарного файлу';


--
-- Name: seq_template_files; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_template_files
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_template_files OWNER TO kbase;

--
-- Name: seq_template_files; Type: SEQUENCE OWNED BY; Schema: kbase; Owner: kbase
--

ALTER SEQUENCE kbase.seq_template_files OWNED BY kbase.template_files.id;


--
-- Name: templates; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.templates (
    id bigint NOT NULL,
    parent_id bigint,
    is_dir boolean DEFAULT false NOT NULL,
    is_reserved boolean DEFAULT false NOT NULL,
    name character varying(255) NOT NULL,
    descr character varying(500),
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.templates OWNER TO kbase;

--
-- Name: TABLE templates; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.templates IS 'Шаблони документів у вигляді дерева (директорії та шаблони)';


--
-- Name: COLUMN templates.parent_id; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.templates.parent_id IS 'Батьківський елемент (для деревової структури)';


--
-- Name: COLUMN templates.is_dir; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.templates.is_dir IS 'true - директорія, false - шаблон (кінцевий елемент)';


--
-- Name: COLUMN templates.is_reserved; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.templates.is_reserved IS 'Зарезервовані елементи';


--
-- Name: seq_templates; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_templates
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_templates OWNER TO kbase;

--
-- Name: seq_templates; Type: SEQUENCE OWNED BY; Schema: kbase; Owner: kbase
--

ALTER SEQUENCE kbase.seq_templates OWNED BY kbase.templates.id;


--
-- Name: seq_user_groups; Type: SEQUENCE; Schema: kbase; Owner: postgres
--

CREATE SEQUENCE kbase.seq_user_groups
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_user_groups OWNER TO postgres;

--
-- Name: seq_users; Type: SEQUENCE; Schema: kbase; Owner: kbase
--

CREATE SEQUENCE kbase.seq_users
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE kbase.seq_users OWNER TO kbase;

--
-- Name: settings; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.settings (
    id bigint DEFAULT nextval('kbase.seq_settings'::regclass) NOT NULL,
    alias character varying(50) NOT NULL,
    section character varying(50),
    subject character varying(50),
    name character varying(50),
    value character varying(50),
    descr character varying(200),
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint DEFAULT 1,
    user_id_modified bigint DEFAULT 1
);


ALTER TABLE kbase.settings OWNER TO kbase;

--
-- Name: TABLE settings; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON TABLE kbase.settings IS 'Для збереження налаштувань програми на рівні БД.';


--
-- Name: COLUMN settings.alias; Type: COMMENT; Schema: kbase; Owner: kbase
--

COMMENT ON COLUMN kbase.settings.alias IS 'Текстовий унікальний ідентифікатор';


--
-- Name: user_groups; Type: TABLE; Schema: kbase; Owner: postgres
--

CREATE TABLE kbase.user_groups (
    id bigint DEFAULT nextval('kbase.seq_user_groups'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    group_id bigint NOT NULL,
    descr character varying,
    date_created timestamp with time zone DEFAULT now() NOT NULL,
    date_modified timestamp with time zone DEFAULT now() NOT NULL,
    user_id_created bigint NOT NULL,
    user_id_modified bigint NOT NULL
);


ALTER TABLE kbase.user_groups OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: kbase; Owner: kbase
--

CREATE TABLE kbase.users (
    id bigint DEFAULT nextval('kbase.seq_users'::regclass) NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(100) NOT NULL,
    email character varying(100),
    role_id bigint,
    active boolean DEFAULT true NOT NULL,
    date_created timestamp with time zone DEFAULT now(),
    date_modified timestamp with time zone DEFAULT now(),
    user_id_created bigint DEFAULT 1,
    user_id_modified bigint DEFAULT 1
);


ALTER TABLE kbase.users OWNER TO kbase;

--
-- Name: log_types id; Type: DEFAULT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.log_types ALTER COLUMN id SET DEFAULT nextval('kbase.log_types_id_seq'::regclass);


--
-- Name: template_bodies id; Type: DEFAULT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_bodies ALTER COLUMN id SET DEFAULT nextval('kbase.seq_template_bodies'::regclass);


--
-- Name: template_color_themes id; Type: DEFAULT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_color_themes ALTER COLUMN id SET DEFAULT nextval('kbase.seq_template_color_themes'::regclass);


--
-- Name: template_files id; Type: DEFAULT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_files ALTER COLUMN id SET DEFAULT nextval('kbase.seq_template_files'::regclass);


--
-- Name: templates id; Type: DEFAULT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.templates ALTER COLUMN id SET DEFAULT nextval('kbase.seq_templates'::regclass);


--
-- Data for Name: groups; Type: TABLE DATA; Schema: kbase; Owner: postgres
--

COPY kbase.groups (id, name, descr, is_active, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
1	Адміністратори	Full system access	t	2026-07-29 14:07:48.284279+03	2026-07-29 14:07:48.284279+03	1	1
2	Розробники	Developers with edit access	t	2026-07-29 14:07:48.284279+03	2026-07-29 14:07:48.284279+03	1	1
3	Тестери	Testers with view/edit access	t	2026-07-29 14:07:48.284279+03	2026-07-29 14:07:48.284279+03	1	1
4	Супровід	Support team with view/edit access	t	2026-07-29 14:07:48.284279+03	2026-07-29 14:07:48.284279+03	1	1
5	Менеджери	Managers with view access	t	2026-07-29 14:07:48.284279+03	2026-07-29 14:07:48.284279+03	1	1
6	Бухгалтери	Accountants with limited access	t	2026-07-29 14:07:48.284279+03	2026-07-29 14:07:48.284279+03	1	1
\.


--
-- Data for Name: icons; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.icons (id, parent_id, name, descr, image, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: log_types; Type: TABLE DATA; Schema: kbase; Owner: postgres
--

COPY kbase.log_types (id, name, description, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
1	info	Informational messages	2026-07-25 17:14:26.514223+03	2026-07-25 17:14:26.514223+03	1	1
2	warning	Warning messages	2026-07-25 17:14:26.514223+03	2026-07-25 17:14:26.514223+03	1	1
3	error	Error messages	2026-07-25 17:14:26.514223+03	2026-07-25 17:14:26.514223+03	1	1
4	debug	Debug messages	2026-07-25 17:14:26.514223+03	2026-07-25 17:14:26.514223+03	1	1
5	audit	Audit trail entries	2026-07-25 17:14:26.514223+03	2026-07-25 17:14:26.514223+03	1	1
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.logs (id, text, date_created, user_id_created, log_type_id) FROM stdin;
\.


--
-- Data for Name: privileges; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.privileges (id, name, descr, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
5	admin	Full access: edit users, roles, privileges, global settings	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
6	admin-view	View users, roles, privileges, global settings	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
7	icons-edit	Edit icons	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
8	icons-view	View icons	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
9	logs-view	View logs	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
10	sections-full	Full access to all sections	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
11	sections-edit	Edit sections	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
12	sections-view	View sections	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
13	section_categories-edit	Edit section categories	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
14	section_categories-view	View section categories	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
15	section_document_info_block_styles-edit	Edit document info block styles	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
16	section_document_info_block_styles-view	View document info block styles	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
17	templates-edit	Edit templates	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
18	templates-view	View templates	2026-07-29 13:50:28.776339+03	2026-07-29 13:50:28.776339+03	1	1
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.refresh_tokens (id, token, user_id, expiry_date) FROM stdin;
29	eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTc4Mzk0ODU2NCwiZXhwIjoxNzg2NTQwNTY0fQ.u4r9JrX7a6BAf30o6MlofFTqYrEf7x08ou0SwmbNHpw	1	2026-08-12 19:16:04+03
\.


--
-- Data for Name: role_privileges; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.role_privileges (role_id, privilege_id, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
1	5	2026-07-29 14:07:48.290921+03	2026-07-29 14:07:48.290921+03	1	1
1	7	2026-07-29 14:07:48.290921+03	2026-07-29 14:07:48.290921+03	1	1
1	9	2026-07-29 14:07:48.290921+03	2026-07-29 14:07:48.290921+03	1	1
1	10	2026-07-29 14:07:48.290921+03	2026-07-29 14:07:48.290921+03	1	1
1	13	2026-07-29 14:07:48.290921+03	2026-07-29 14:07:48.290921+03	1	1
1	15	2026-07-29 14:07:48.290921+03	2026-07-29 14:07:48.290921+03	1	1
1	17	2026-07-29 14:07:48.290921+03	2026-07-29 14:07:48.290921+03	1	1
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.roles (id, name, descr, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
1	ROLE_ADMIN	Адміністратор системи з повним доступом	2026-07-08 21:14:08.384343+03	2026-07-08 21:14:08.384343+03	1	1
2	ROLE_USER	Користувач системи з правом перегляду та редагування	2026-07-08 21:14:08.384343+03	2026-07-08 21:14:08.384343+03	1	1
3	ROLE_VIEWER	Переглядач з правом лише читання	2026-07-11 13:16:29.976038+03	2026-07-11 13:16:29.976038+03	1	1
\.


--
-- Data for Name: section_categories; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_categories (id, parent_id, name, descr, icon_id, template_id, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: section_dictionaries; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_dictionaries (id, section_id, type_id, name, value, descr, rating, reverse, status, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: section_document_info_block_components_binary; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_document_info_block_components_binary (id, section_document_info_block_header_id, section_document_info_block_type_component_id, storage_type, value, file_path, file_size, mime_type, original_filename, checksum, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: section_document_info_block_components_number; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_document_info_block_components_number (id, section_document_info_block_header_id, section_document_info_block_type_component_id, value, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: section_document_info_block_components_text; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_document_info_block_components_text (id, section_document_info_block_header_id, section_document_info_block_type_component_id, value, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: section_document_info_block_headers; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_document_info_block_headers (id, section_id, section_document_info_block_type_id, section_document_info_block_style_id, "position", name, descr, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: section_document_info_block_styles; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_document_info_block_styles (id, parent_id, name, descr, icon_id, template_id, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: section_document_info_block_type; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_document_info_block_type (id, name, descr, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
1	Текст	Текстовий інфоблок	2026-07-18 20:31:14.135566+03	2026-07-18 20:31:14.135566+03	1	1
2	Картинка	Інфоблок зображення	2026-07-18 20:31:14.135566+03	2026-07-18 20:31:14.135566+03	1	1
3	Файл	Інфоблок файлу	2026-07-18 20:31:14.135566+03	2026-07-18 20:31:14.135566+03	1	1
\.


--
-- Data for Name: section_document_info_block_type_components; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_document_info_block_type_components (id, section_document_info_block_type_id, name, descr, component_type, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
1	1	title	Заголовок	1	2026-07-18 20:34:52.05272+03	2026-07-18 20:34:52.05272+03	1	1
2	1	text	Текст	1	2026-07-18 20:34:52.05272+03	2026-07-18 20:34:52.05272+03	1	1
3	1	is_show_title	Показувати заголовок	5	2026-07-18 20:34:52.05272+03	2026-07-18 20:34:52.05272+03	1	1
4	2	title	Заголовок	1	2026-07-18 20:34:52.055367+03	2026-07-18 20:34:52.055367+03	1	1
5	2	image	Зображення	2	2026-07-18 20:34:52.055367+03	2026-07-18 20:34:52.055367+03	1	1
6	2	width	Ширина	4	2026-07-18 20:34:52.055367+03	2026-07-18 20:34:52.055367+03	1	1
7	2	height	Висота	4	2026-07-18 20:34:52.055367+03	2026-07-18 20:34:52.055367+03	1	1
8	2	descr	Опис	1	2026-07-18 20:34:52.055367+03	2026-07-18 20:34:52.055367+03	1	1
9	2	text	Текст	1	2026-07-18 20:34:52.055367+03	2026-07-18 20:34:52.055367+03	1	1
10	2	is_show_title	Показувати заголовок	5	2026-07-18 20:34:52.055367+03	2026-07-18 20:34:52.055367+03	1	1
11	2	is_show_descr	Показувати опис	5	2026-07-18 20:34:52.055367+03	2026-07-18 20:34:52.055367+03	1	1
12	2	is_show_text	Показувати текст	5	2026-07-18 20:34:52.055367+03	2026-07-18 20:34:52.055367+03	1	1
13	3	title	Заголовок	1	2026-07-18 20:34:52.057077+03	2026-07-18 20:34:52.057077+03	1	1
14	3	file_body	Вміст файлу	3	2026-07-18 20:34:52.057077+03	2026-07-18 20:34:52.057077+03	1	1
15	3	file_name	Назва файлу	1	2026-07-18 20:34:52.057077+03	2026-07-18 20:34:52.057077+03	1	1
16	3	icon_id	Іконка файлу	4	2026-07-18 20:34:52.057077+03	2026-07-18 20:34:52.057077+03	1	1
17	3	descr	Опис	1	2026-07-18 20:34:52.057077+03	2026-07-18 20:34:52.057077+03	1	1
18	3	text	Текст	1	2026-07-18 20:34:52.057077+03	2026-07-18 20:34:52.057077+03	1	1
19	3	is_show_title	Показувати заголовок	5	2026-07-18 20:34:52.057077+03	2026-07-18 20:34:52.057077+03	1	1
20	3	is_show_descr	Показувати опис	5	2026-07-18 20:34:52.057077+03	2026-07-18 20:34:52.057077+03	1	1
21	3	is_show_text	Показувати текст	5	2026-07-18 20:34:52.057077+03	2026-07-18 20:34:52.057077+03	1	1
\.


--
-- Data for Name: section_documents; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_documents (id, section_id, body, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: section_group_access; Type: TABLE DATA; Schema: kbase; Owner: postgres
--

COPY kbase.section_group_access (section_id, group_id, access_level, is_inherited, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: section_types; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.section_types (id, name, descr, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
1	документ	Тип Розділу для документів	2026-07-17 19:00:08.939579+03	2026-07-17 19:00:08.939579+03	1	1
2	словник	Тип Розділу для словників	2026-07-17 19:00:08.939579+03	2026-07-17 19:00:08.939579+03	1	1
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.sections (id, parent_id, name, descr, section_type_id, section_category_id, section_category_id_dir, section_category_id_def, date_created, date_modified, date_modified_info, user_id_created, user_id_modified, section_path) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.settings (id, alias, section, subject, name, value, descr, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
1	VERSION_DB_BEGIN_DATE	Version	Db	Begin date	05.07.2026		2026-07-05 13:53:54.975748+03	2026-07-05 13:53:54.975748+03	1	1
2	VERSION_DB_NUMBER	Version	Db	number	1.00.00.007	ltree suport	2026-07-05 13:53:54.975748+03	2026-07-29 14:41:16.100785+03	1	1
3	VERSION_DB_END_DATE	Version	Db	End date	29.07.2026		2026-07-05 13:53:54.975748+03	2026-07-29 14:41:16.102118+03	1	1
\.


--
-- Data for Name: template_bodies; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.template_bodies (id, template_id, template_color_theme_id, body, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: template_color_themes; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.template_color_themes (id, name, type, is_default, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
1	Стандартна світла	light	t	2026-07-18 19:25:34.98456+03	2026-07-18 19:25:34.98456+03	1	1
2	Стандартна темна	dark	t	2026-07-18 19:25:34.98456+03	2026-07-18 19:25:34.98456+03	1	1
\.


--
-- Data for Name: template_files; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.template_files (id, parent_id, is_dir, is_reserved, file_type, file_name, descr, body, body_bin, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.templates (id, parent_id, is_dir, is_reserved, name, descr, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
\.


--
-- Data for Name: user_groups; Type: TABLE DATA; Schema: kbase; Owner: postgres
--

COPY kbase.user_groups (id, user_id, group_id, descr, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
1	1	1	Admin group assignment	2026-07-29 14:07:48.286659+03	2026-07-29 14:07:48.286659+03	1	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: kbase; Owner: kbase
--

COPY kbase.users (id, username, password, email, role_id, active, date_created, date_modified, user_id_created, user_id_modified) FROM stdin;
3	viewer	$2b$10$dhXyq9dlwcSb9n0yV3CFa.F.QMyVIF2d2.1FoZepAM7h7uuI9/62y	viewer@kbase.ua	3	t	2026-07-11 13:16:41.00474+03	2026-07-11 13:16:41.00474+03	1	1
2	user	$2b$10$50XpGUYHg628NivdFMQZrent9y3pdu9DZQZQAxb1ZVOJ/FnsbOtB.	user@kbase.ua	2	t	2026-07-08 21:14:08.39448+03	2026-07-08 21:14:08.39448+03	1	1
1	admin	$2a$10$K80zooFlJd27NjPCZzGsSO13fOpeyaLIHwkrILlZk2w6O4cRVEt16	admin@kbase-web.ua	1	t	2026-07-08 21:14:08.392763+03	2026-07-12 17:55:14.019287+03	1	1
\.


--
-- Name: log_types_id_seq; Type: SEQUENCE SET; Schema: kbase; Owner: postgres
--

SELECT pg_catalog.setval('kbase.log_types_id_seq', 5, true);


--
-- Name: seq_groups; Type: SEQUENCE SET; Schema: kbase; Owner: postgres
--

SELECT pg_catalog.setval('kbase.seq_groups', 6, true);


--
-- Name: seq_icons; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_icons', 1, false);


--
-- Name: seq_logs; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_logs', 1, false);


--
-- Name: seq_privileges; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_privileges', 18, true);


--
-- Name: seq_refresh_tokens; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_refresh_tokens', 29, true);


--
-- Name: seq_roles; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_roles', 3, true);


--
-- Name: seq_section_categories; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_section_categories', 1, false);


--
-- Name: seq_section_dictionaries; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_section_dictionaries', 1, false);


--
-- Name: seq_section_document_info_block_components_binary; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_section_document_info_block_components_binary', 1, false);


--
-- Name: seq_section_document_info_block_components_number; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_section_document_info_block_components_number', 1, false);


--
-- Name: seq_section_document_info_block_components_text; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_section_document_info_block_components_text', 1, false);


--
-- Name: seq_section_document_info_block_headers; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_section_document_info_block_headers', 1, false);


--
-- Name: seq_section_document_info_block_styles; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_section_document_info_block_styles', 1, false);


--
-- Name: seq_section_document_info_block_type; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_section_document_info_block_type', 1, false);


--
-- Name: seq_section_document_info_block_type_components; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_section_document_info_block_type_components', 1, false);


--
-- Name: seq_section_documents; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_section_documents', 1, false);


--
-- Name: seq_section_group_access; Type: SEQUENCE SET; Schema: kbase; Owner: postgres
--

SELECT pg_catalog.setval('kbase.seq_section_group_access', 1, false);


--
-- Name: seq_sections; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_sections', 1, false);


--
-- Name: seq_settings; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_settings', 3, true);


--
-- Name: seq_template_bodies; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_template_bodies', 1, false);


--
-- Name: seq_template_color_themes; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_template_color_themes', 1, false);


--
-- Name: seq_template_files; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_template_files', 1, false);


--
-- Name: seq_templates; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_templates', 1, false);


--
-- Name: seq_user_groups; Type: SEQUENCE SET; Schema: kbase; Owner: postgres
--

SELECT pg_catalog.setval('kbase.seq_user_groups', 1, true);


--
-- Name: seq_users; Type: SEQUENCE SET; Schema: kbase; Owner: kbase
--

SELECT pg_catalog.setval('kbase.seq_users', 3, true);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: privileges k_privileges_name; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.privileges
    ADD CONSTRAINT k_privileges_name UNIQUE (name);


--
-- Name: refresh_tokens k_refresh_tokens_token; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.refresh_tokens
    ADD CONSTRAINT k_refresh_tokens_token UNIQUE (token);


--
-- Name: roles k_roles_name; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.roles
    ADD CONSTRAINT k_roles_name UNIQUE (name);


--
-- Name: settings k_settings_alias; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.settings
    ADD CONSTRAINT k_settings_alias UNIQUE (alias);


--
-- Name: users k_users_username; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.users
    ADD CONSTRAINT k_users_username UNIQUE (username);


--
-- Name: log_types log_types_name_key; Type: CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.log_types
    ADD CONSTRAINT log_types_name_key UNIQUE (name);


--
-- Name: log_types log_types_pkey; Type: CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.log_types
    ADD CONSTRAINT log_types_pkey PRIMARY KEY (id);


--
-- Name: icons pk_icons_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.icons
    ADD CONSTRAINT pk_icons_id PRIMARY KEY (id);


--
-- Name: section_types pk_infotype_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_types
    ADD CONSTRAINT pk_infotype_id PRIMARY KEY (id);


--
-- Name: logs pk_logs; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.logs
    ADD CONSTRAINT pk_logs PRIMARY KEY (id);


--
-- Name: privileges pk_privileges_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.privileges
    ADD CONSTRAINT pk_privileges_id PRIMARY KEY (id);


--
-- Name: refresh_tokens pk_refresh_tokens_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.refresh_tokens
    ADD CONSTRAINT pk_refresh_tokens_id PRIMARY KEY (id);


--
-- Name: role_privileges pk_role_privileges; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.role_privileges
    ADD CONSTRAINT pk_role_privileges PRIMARY KEY (role_id, privilege_id);


--
-- Name: roles pk_roles_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.roles
    ADD CONSTRAINT pk_roles_id PRIMARY KEY (id);


--
-- Name: section_categories pk_section_categories_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_categories
    ADD CONSTRAINT pk_section_categories_id PRIMARY KEY (id);


--
-- Name: section_dictionaries pk_section_dictionaries_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_dictionaries
    ADD CONSTRAINT pk_section_dictionaries_id PRIMARY KEY (id);


--
-- Name: section_document_info_block_components_binary pk_section_document_info_block_components_binary_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_binary
    ADD CONSTRAINT pk_section_document_info_block_components_binary_id PRIMARY KEY (id);


--
-- Name: section_document_info_block_components_number pk_section_document_info_block_components_number_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_number
    ADD CONSTRAINT pk_section_document_info_block_components_number_id PRIMARY KEY (id);


--
-- Name: section_document_info_block_components_text pk_section_document_info_block_components_text_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_text
    ADD CONSTRAINT pk_section_document_info_block_components_text_id PRIMARY KEY (id);


--
-- Name: section_document_info_block_headers pk_section_document_info_block_headers_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_headers
    ADD CONSTRAINT pk_section_document_info_block_headers_id PRIMARY KEY (id);


--
-- Name: section_document_info_block_styles pk_section_document_info_block_styles_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_styles
    ADD CONSTRAINT pk_section_document_info_block_styles_id PRIMARY KEY (id);


--
-- Name: section_document_info_block_type_components pk_section_document_info_block_type_components_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_type_components
    ADD CONSTRAINT pk_section_document_info_block_type_components_id PRIMARY KEY (id);


--
-- Name: section_document_info_block_type pk_section_document_info_block_type_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_type
    ADD CONSTRAINT pk_section_document_info_block_type_id PRIMARY KEY (id);


--
-- Name: section_documents pk_section_documents_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_documents
    ADD CONSTRAINT pk_section_documents_id PRIMARY KEY (id);


--
-- Name: sections pk_sections_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.sections
    ADD CONSTRAINT pk_sections_id PRIMARY KEY (id);


--
-- Name: settings pk_settings_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.settings
    ADD CONSTRAINT pk_settings_id PRIMARY KEY (id);


--
-- Name: template_bodies pk_template_bodies_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_bodies
    ADD CONSTRAINT pk_template_bodies_id PRIMARY KEY (id);


--
-- Name: template_color_themes pk_template_color_themes_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_color_themes
    ADD CONSTRAINT pk_template_color_themes_id PRIMARY KEY (id);


--
-- Name: template_files pk_template_files_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_files
    ADD CONSTRAINT pk_template_files_id PRIMARY KEY (id);


--
-- Name: templates pk_templates_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.templates
    ADD CONSTRAINT pk_templates_id PRIMARY KEY (id);


--
-- Name: users pk_users_id; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.users
    ADD CONSTRAINT pk_users_id PRIMARY KEY (id);


--
-- Name: section_group_access section_group_access_pkey; Type: CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.section_group_access
    ADD CONSTRAINT section_group_access_pkey PRIMARY KEY (section_id, group_id);


--
-- Name: section_document_info_block_headers uk_section_document_info_block_headers_section_position; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_headers
    ADD CONSTRAINT uk_section_document_info_block_headers_section_position UNIQUE (section_id, "position");


--
-- Name: template_bodies uk_template_bodies_template_theme; Type: CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_bodies
    ADD CONSTRAINT uk_template_bodies_template_theme UNIQUE (template_id, template_color_theme_id);


--
-- Name: user_groups user_groups_pkey; Type: CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.user_groups
    ADD CONSTRAINT user_groups_pkey PRIMARY KEY (id);


--
-- Name: user_groups user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.user_groups
    ADD CONSTRAINT user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: idx_icons_parent_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_icons_parent_id ON kbase.icons USING btree (parent_id);


--
-- Name: idx_refresh_tokens_expiry_date; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_refresh_tokens_expiry_date ON kbase.refresh_tokens USING btree (expiry_date);


--
-- Name: idx_refresh_tokens_user_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_refresh_tokens_user_id ON kbase.refresh_tokens USING btree (user_id);


--
-- Name: idx_section_categories_parent_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_categories_parent_id ON kbase.section_categories USING btree (parent_id);


--
-- Name: idx_section_dictionaries_rating; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_dictionaries_rating ON kbase.section_dictionaries USING btree (rating);


--
-- Name: idx_section_dictionaries_section_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_dictionaries_section_id ON kbase.section_dictionaries USING btree (section_id);


--
-- Name: idx_section_dictionaries_status; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_dictionaries_status ON kbase.section_dictionaries USING btree (status);


--
-- Name: idx_section_dictionaries_type_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_dictionaries_type_id ON kbase.section_dictionaries USING btree (type_id);


--
-- Name: idx_section_document_info_block_components_binary_header_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_components_binary_header_id ON kbase.section_document_info_block_components_binary USING btree (section_document_info_block_header_id);


--
-- Name: idx_section_document_info_block_components_binary_storage_type; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_components_binary_storage_type ON kbase.section_document_info_block_components_binary USING btree (storage_type);


--
-- Name: idx_section_document_info_block_components_binary_type_componen; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_components_binary_type_componen ON kbase.section_document_info_block_components_binary USING btree (section_document_info_block_type_component_id);


--
-- Name: idx_section_document_info_block_components_number_header_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_components_number_header_id ON kbase.section_document_info_block_components_number USING btree (section_document_info_block_header_id);


--
-- Name: idx_section_document_info_block_components_number_type_componen; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_components_number_type_componen ON kbase.section_document_info_block_components_number USING btree (section_document_info_block_type_component_id);


--
-- Name: idx_section_document_info_block_components_text_header_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_components_text_header_id ON kbase.section_document_info_block_components_text USING btree (section_document_info_block_header_id);


--
-- Name: idx_section_document_info_block_components_text_type_component_; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_components_text_type_component_ ON kbase.section_document_info_block_components_text USING btree (section_document_info_block_type_component_id);


--
-- Name: idx_section_document_info_block_headers_section_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_headers_section_id ON kbase.section_document_info_block_headers USING btree (section_id);


--
-- Name: idx_section_document_info_block_headers_style_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_headers_style_id ON kbase.section_document_info_block_headers USING btree (section_document_info_block_style_id);


--
-- Name: idx_section_document_info_block_headers_type_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_headers_type_id ON kbase.section_document_info_block_headers USING btree (section_document_info_block_type_id);


--
-- Name: idx_section_document_info_block_styles_parent_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_styles_parent_id ON kbase.section_document_info_block_styles USING btree (parent_id);


--
-- Name: idx_section_document_info_block_styles_template_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_styles_template_id ON kbase.section_document_info_block_styles USING btree (template_id);


--
-- Name: idx_section_document_info_block_type_components_type_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_document_info_block_type_components_type_id ON kbase.section_document_info_block_type_components USING btree (section_document_info_block_type_id);


--
-- Name: idx_section_documents_section_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_section_documents_section_id ON kbase.section_documents USING btree (section_id);


--
-- Name: idx_section_group_access_group_id; Type: INDEX; Schema: kbase; Owner: postgres
--

CREATE INDEX idx_section_group_access_group_id ON kbase.section_group_access USING btree (group_id);


--
-- Name: idx_section_group_access_section_id; Type: INDEX; Schema: kbase; Owner: postgres
--

CREATE INDEX idx_section_group_access_section_id ON kbase.section_group_access USING btree (section_id);


--
-- Name: idx_sections_parent_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_sections_parent_id ON kbase.sections USING btree (parent_id);


--
-- Name: idx_sections_path_btree; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_sections_path_btree ON kbase.sections USING btree (section_path);


--
-- Name: idx_sections_path_gist; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_sections_path_gist ON kbase.sections USING gist (section_path);


--
-- Name: idx_sections_user_id_created; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_sections_user_id_created ON kbase.sections USING btree (user_id_created);


--
-- Name: idx_sections_user_id_modified; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_sections_user_id_modified ON kbase.sections USING btree (user_id_modified);


--
-- Name: idx_template_bodies_template_color_theme_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_template_bodies_template_color_theme_id ON kbase.template_bodies USING btree (template_color_theme_id);


--
-- Name: idx_template_bodies_template_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_template_bodies_template_id ON kbase.template_bodies USING btree (template_id);


--
-- Name: idx_template_files_is_dir; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_template_files_is_dir ON kbase.template_files USING btree (is_dir);


--
-- Name: idx_template_files_is_reserved; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_template_files_is_reserved ON kbase.template_files USING btree (is_reserved);


--
-- Name: idx_template_files_parent_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_template_files_parent_id ON kbase.template_files USING btree (parent_id);


--
-- Name: idx_templates_is_dir; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_templates_is_dir ON kbase.templates USING btree (is_dir);


--
-- Name: idx_templates_parent_id; Type: INDEX; Schema: kbase; Owner: kbase
--

CREATE INDEX idx_templates_parent_id ON kbase.templates USING btree (parent_id);


--
-- Name: idx_user_groups_group_id; Type: INDEX; Schema: kbase; Owner: postgres
--

CREATE INDEX idx_user_groups_group_id ON kbase.user_groups USING btree (group_id);


--
-- Name: idx_user_groups_user_id; Type: INDEX; Schema: kbase; Owner: postgres
--

CREATE INDEX idx_user_groups_user_id ON kbase.user_groups USING btree (user_id);


--
-- Name: section_dictionaries trigger_section_dictionaries_update_sections; Type: TRIGGER; Schema: kbase; Owner: kbase
--

CREATE TRIGGER trigger_section_dictionaries_update_sections AFTER INSERT OR DELETE OR UPDATE ON kbase.section_dictionaries FOR EACH ROW EXECUTE FUNCTION kbase.trg_section_update_date_modified_info();


--
-- Name: section_document_info_block_headers trigger_section_document_info_block_headers_update_sections; Type: TRIGGER; Schema: kbase; Owner: kbase
--

CREATE TRIGGER trigger_section_document_info_block_headers_update_sections AFTER INSERT OR DELETE OR UPDATE ON kbase.section_document_info_block_headers FOR EACH ROW EXECUTE FUNCTION kbase.trg_section_update_date_modified_info();


--
-- Name: sections trigger_section_set_path; Type: TRIGGER; Schema: kbase; Owner: kbase
--

CREATE TRIGGER trigger_section_set_path BEFORE INSERT ON kbase.sections FOR EACH ROW EXECUTE FUNCTION kbase.trg_section_set_path();


--
-- Name: sections trigger_section_update_path_on_move; Type: TRIGGER; Schema: kbase; Owner: kbase
--

CREATE TRIGGER trigger_section_update_path_on_move BEFORE UPDATE OF parent_id ON kbase.sections FOR EACH ROW EXECUTE FUNCTION kbase.trg_section_update_path_on_move();


--
-- Name: icons fk_icons_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.icons
    ADD CONSTRAINT fk_icons_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: icons fk_icons_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.icons
    ADD CONSTRAINT fk_icons_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: logs fk_logs_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.logs
    ADD CONSTRAINT fk_logs_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: privileges fk_privileges_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.privileges
    ADD CONSTRAINT fk_privileges_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: privileges fk_privileges_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.privileges
    ADD CONSTRAINT fk_privileges_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: refresh_tokens fk_refresh_tokens_user; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.refresh_tokens
    ADD CONSTRAINT fk_refresh_tokens_user FOREIGN KEY (user_id) REFERENCES kbase.users(id) ON DELETE CASCADE;


--
-- Name: role_privileges fk_role_privileges_privilege; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.role_privileges
    ADD CONSTRAINT fk_role_privileges_privilege FOREIGN KEY (privilege_id) REFERENCES kbase.privileges(id) ON DELETE CASCADE;


--
-- Name: role_privileges fk_role_privileges_role; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.role_privileges
    ADD CONSTRAINT fk_role_privileges_role FOREIGN KEY (role_id) REFERENCES kbase.roles(id) ON DELETE CASCADE;


--
-- Name: role_privileges fk_role_privileges_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.role_privileges
    ADD CONSTRAINT fk_role_privileges_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: role_privileges fk_role_privileges_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.role_privileges
    ADD CONSTRAINT fk_role_privileges_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: roles fk_roles_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.roles
    ADD CONSTRAINT fk_roles_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: roles fk_roles_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.roles
    ADD CONSTRAINT fk_roles_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_categories fk_section_categories_icon_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_categories
    ADD CONSTRAINT fk_section_categories_icon_id FOREIGN KEY (icon_id) REFERENCES kbase.icons(id);


--
-- Name: section_categories fk_section_categories_parent_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_categories
    ADD CONSTRAINT fk_section_categories_parent_id FOREIGN KEY (parent_id) REFERENCES kbase.section_categories(id) ON DELETE CASCADE;


--
-- Name: section_categories fk_section_categories_template_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_categories
    ADD CONSTRAINT fk_section_categories_template_id FOREIGN KEY (template_id) REFERENCES kbase.templates(id);


--
-- Name: section_categories fk_section_categories_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_categories
    ADD CONSTRAINT fk_section_categories_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_categories fk_section_categories_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_categories
    ADD CONSTRAINT fk_section_categories_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_dictionaries fk_section_dictionaries_section_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_dictionaries
    ADD CONSTRAINT fk_section_dictionaries_section_id FOREIGN KEY (section_id) REFERENCES kbase.sections(id) ON DELETE CASCADE;


--
-- Name: section_dictionaries fk_section_dictionaries_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_dictionaries
    ADD CONSTRAINT fk_section_dictionaries_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_dictionaries fk_section_dictionaries_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_dictionaries
    ADD CONSTRAINT fk_section_dictionaries_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_components_binary fk_section_document_info_block_components_binary_header_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_binary
    ADD CONSTRAINT fk_section_document_info_block_components_binary_header_id FOREIGN KEY (section_document_info_block_header_id) REFERENCES kbase.section_document_info_block_headers(id) ON DELETE CASCADE;


--
-- Name: section_document_info_block_components_binary fk_section_document_info_block_components_binary_type_component; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_binary
    ADD CONSTRAINT fk_section_document_info_block_components_binary_type_component FOREIGN KEY (section_document_info_block_type_component_id) REFERENCES kbase.section_document_info_block_type_components(id);


--
-- Name: section_document_info_block_components_binary fk_section_document_info_block_components_binary_user_id_create; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_binary
    ADD CONSTRAINT fk_section_document_info_block_components_binary_user_id_create FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_components_binary fk_section_document_info_block_components_binary_user_id_modifi; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_binary
    ADD CONSTRAINT fk_section_document_info_block_components_binary_user_id_modifi FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_components_number fk_section_document_info_block_components_number_header_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_number
    ADD CONSTRAINT fk_section_document_info_block_components_number_header_id FOREIGN KEY (section_document_info_block_header_id) REFERENCES kbase.section_document_info_block_headers(id) ON DELETE CASCADE;


--
-- Name: section_document_info_block_components_number fk_section_document_info_block_components_number_type_component; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_number
    ADD CONSTRAINT fk_section_document_info_block_components_number_type_component FOREIGN KEY (section_document_info_block_type_component_id) REFERENCES kbase.section_document_info_block_type_components(id);


--
-- Name: section_document_info_block_components_number fk_section_document_info_block_components_number_user_id_create; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_number
    ADD CONSTRAINT fk_section_document_info_block_components_number_user_id_create FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_components_number fk_section_document_info_block_components_number_user_id_modifi; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_number
    ADD CONSTRAINT fk_section_document_info_block_components_number_user_id_modifi FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_components_text fk_section_document_info_block_components_text_header_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_text
    ADD CONSTRAINT fk_section_document_info_block_components_text_header_id FOREIGN KEY (section_document_info_block_header_id) REFERENCES kbase.section_document_info_block_headers(id) ON DELETE CASCADE;


--
-- Name: section_document_info_block_components_text fk_section_document_info_block_components_text_type_component_i; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_text
    ADD CONSTRAINT fk_section_document_info_block_components_text_type_component_i FOREIGN KEY (section_document_info_block_type_component_id) REFERENCES kbase.section_document_info_block_type_components(id);


--
-- Name: section_document_info_block_components_text fk_section_document_info_block_components_text_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_text
    ADD CONSTRAINT fk_section_document_info_block_components_text_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_components_text fk_section_document_info_block_components_text_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_components_text
    ADD CONSTRAINT fk_section_document_info_block_components_text_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_headers fk_section_document_info_block_headers_section_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_headers
    ADD CONSTRAINT fk_section_document_info_block_headers_section_id FOREIGN KEY (section_id) REFERENCES kbase.sections(id) ON DELETE CASCADE;


--
-- Name: section_document_info_block_headers fk_section_document_info_block_headers_style_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_headers
    ADD CONSTRAINT fk_section_document_info_block_headers_style_id FOREIGN KEY (section_document_info_block_style_id) REFERENCES kbase.section_document_info_block_styles(id);


--
-- Name: section_document_info_block_headers fk_section_document_info_block_headers_type_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_headers
    ADD CONSTRAINT fk_section_document_info_block_headers_type_id FOREIGN KEY (section_document_info_block_type_id) REFERENCES kbase.section_document_info_block_type(id);


--
-- Name: section_document_info_block_headers fk_section_document_info_block_headers_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_headers
    ADD CONSTRAINT fk_section_document_info_block_headers_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_headers fk_section_document_info_block_headers_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_headers
    ADD CONSTRAINT fk_section_document_info_block_headers_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_styles fk_section_document_info_block_styles_icon_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_styles
    ADD CONSTRAINT fk_section_document_info_block_styles_icon_id FOREIGN KEY (icon_id) REFERENCES kbase.icons(id) ON DELETE SET NULL;


--
-- Name: section_document_info_block_styles fk_section_document_info_block_styles_parent_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_styles
    ADD CONSTRAINT fk_section_document_info_block_styles_parent_id FOREIGN KEY (parent_id) REFERENCES kbase.section_document_info_block_styles(id) ON DELETE CASCADE;


--
-- Name: section_document_info_block_styles fk_section_document_info_block_styles_template_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_styles
    ADD CONSTRAINT fk_section_document_info_block_styles_template_id FOREIGN KEY (template_id) REFERENCES kbase.templates(id) ON DELETE SET NULL;


--
-- Name: section_document_info_block_styles fk_section_document_info_block_styles_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_styles
    ADD CONSTRAINT fk_section_document_info_block_styles_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_styles fk_section_document_info_block_styles_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_styles
    ADD CONSTRAINT fk_section_document_info_block_styles_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_type_components fk_section_document_info_block_type_components_type_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_type_components
    ADD CONSTRAINT fk_section_document_info_block_type_components_type_id FOREIGN KEY (section_document_info_block_type_id) REFERENCES kbase.section_document_info_block_type(id) ON DELETE CASCADE;


--
-- Name: section_document_info_block_type_components fk_section_document_info_block_type_components_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_type_components
    ADD CONSTRAINT fk_section_document_info_block_type_components_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_type_components fk_section_document_info_block_type_components_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_type_components
    ADD CONSTRAINT fk_section_document_info_block_type_components_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_type fk_section_document_info_block_type_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_type
    ADD CONSTRAINT fk_section_document_info_block_type_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_document_info_block_type fk_section_document_info_block_type_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_document_info_block_type
    ADD CONSTRAINT fk_section_document_info_block_type_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_documents fk_section_documents_section_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_documents
    ADD CONSTRAINT fk_section_documents_section_id FOREIGN KEY (section_id) REFERENCES kbase.sections(id) ON DELETE CASCADE;


--
-- Name: section_documents fk_section_documents_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_documents
    ADD CONSTRAINT fk_section_documents_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_documents fk_section_documents_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_documents
    ADD CONSTRAINT fk_section_documents_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: section_types fk_section_types_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_types
    ADD CONSTRAINT fk_section_types_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_types fk_section_types_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.section_types
    ADD CONSTRAINT fk_section_types_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: sections fk_sections_section_category_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.sections
    ADD CONSTRAINT fk_sections_section_category_id FOREIGN KEY (section_category_id) REFERENCES kbase.section_categories(id);


--
-- Name: sections fk_sections_section_type_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.sections
    ADD CONSTRAINT fk_sections_section_type_id FOREIGN KEY (section_type_id) REFERENCES kbase.section_types(id);


--
-- Name: sections fk_sections_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.sections
    ADD CONSTRAINT fk_sections_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: sections fk_sections_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.sections
    ADD CONSTRAINT fk_sections_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: settings fk_settings_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.settings
    ADD CONSTRAINT fk_settings_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: settings fk_settings_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.settings
    ADD CONSTRAINT fk_settings_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: template_bodies fk_template_bodies_template_color_theme_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_bodies
    ADD CONSTRAINT fk_template_bodies_template_color_theme_id FOREIGN KEY (template_color_theme_id) REFERENCES kbase.template_color_themes(id);


--
-- Name: template_bodies fk_template_bodies_template_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_bodies
    ADD CONSTRAINT fk_template_bodies_template_id FOREIGN KEY (template_id) REFERENCES kbase.templates(id) ON DELETE CASCADE;


--
-- Name: template_bodies fk_template_bodies_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_bodies
    ADD CONSTRAINT fk_template_bodies_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: template_bodies fk_template_bodies_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_bodies
    ADD CONSTRAINT fk_template_bodies_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: template_color_themes fk_template_color_themes_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_color_themes
    ADD CONSTRAINT fk_template_color_themes_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: template_color_themes fk_template_color_themes_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_color_themes
    ADD CONSTRAINT fk_template_color_themes_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: template_files fk_template_files_parent_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_files
    ADD CONSTRAINT fk_template_files_parent_id FOREIGN KEY (parent_id) REFERENCES kbase.template_files(id) ON DELETE CASCADE;


--
-- Name: template_files fk_template_files_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_files
    ADD CONSTRAINT fk_template_files_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: template_files fk_template_files_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.template_files
    ADD CONSTRAINT fk_template_files_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: templates fk_templates_parent_id; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.templates
    ADD CONSTRAINT fk_templates_parent_id FOREIGN KEY (parent_id) REFERENCES kbase.templates(id) ON DELETE CASCADE;


--
-- Name: templates fk_templates_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.templates
    ADD CONSTRAINT fk_templates_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: templates fk_templates_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.templates
    ADD CONSTRAINT fk_templates_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: users fk_users_role; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.users
    ADD CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES kbase.roles(id) ON DELETE RESTRICT;


--
-- Name: users fk_users_user_id_created; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.users
    ADD CONSTRAINT fk_users_user_id_created FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: users fk_users_user_id_modified; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.users
    ADD CONSTRAINT fk_users_user_id_modified FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: groups groups_user_id_created_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.groups
    ADD CONSTRAINT groups_user_id_created_fkey FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: groups groups_user_id_modified_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.groups
    ADD CONSTRAINT groups_user_id_modified_fkey FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: log_types log_types_user_id_created_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.log_types
    ADD CONSTRAINT log_types_user_id_created_fkey FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: log_types log_types_user_id_modified_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.log_types
    ADD CONSTRAINT log_types_user_id_modified_fkey FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: logs logs_log_type_id_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: kbase
--

ALTER TABLE ONLY kbase.logs
    ADD CONSTRAINT logs_log_type_id_fkey FOREIGN KEY (log_type_id) REFERENCES kbase.log_types(id);


--
-- Name: section_group_access section_group_access_group_id_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.section_group_access
    ADD CONSTRAINT section_group_access_group_id_fkey FOREIGN KEY (group_id) REFERENCES kbase.groups(id) ON DELETE CASCADE;


--
-- Name: section_group_access section_group_access_section_id_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.section_group_access
    ADD CONSTRAINT section_group_access_section_id_fkey FOREIGN KEY (section_id) REFERENCES kbase.sections(id) ON DELETE CASCADE;


--
-- Name: section_group_access section_group_access_user_id_created_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.section_group_access
    ADD CONSTRAINT section_group_access_user_id_created_fkey FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: section_group_access section_group_access_user_id_modified_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.section_group_access
    ADD CONSTRAINT section_group_access_user_id_modified_fkey FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: user_groups user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.user_groups
    ADD CONSTRAINT user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES kbase.groups(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_user_id_created_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.user_groups
    ADD CONSTRAINT user_groups_user_id_created_fkey FOREIGN KEY (user_id_created) REFERENCES kbase.users(id);


--
-- Name: user_groups user_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.user_groups
    ADD CONSTRAINT user_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES kbase.users(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_user_id_modified_fkey; Type: FK CONSTRAINT; Schema: kbase; Owner: postgres
--

ALTER TABLE ONLY kbase.user_groups
    ADD CONSTRAINT user_groups_user_id_modified_fkey FOREIGN KEY (user_id_modified) REFERENCES kbase.users(id);


--
-- Name: SCHEMA kbase; Type: ACL; Schema: -; Owner: kbase
--

GRANT USAGE ON SCHEMA kbase TO kbase_viewer;


--
-- Name: SCHEMA ltree; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA ltree TO kbase;
GRANT USAGE ON SCHEMA ltree TO kbase_viewer;


--
-- Name: SEQUENCE seq_groups; Type: ACL; Schema: kbase; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE kbase.seq_groups TO kbase;


--
-- Name: TABLE groups; Type: ACL; Schema: kbase; Owner: postgres
--

GRANT SELECT ON TABLE kbase.groups TO kbase_viewer;
GRANT ALL ON TABLE kbase.groups TO kbase;


--
-- Name: TABLE icons; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.icons TO kbase_viewer;


--
-- Name: TABLE log_types; Type: ACL; Schema: kbase; Owner: postgres
--

GRANT SELECT ON TABLE kbase.log_types TO kbase_viewer;


--
-- Name: TABLE logs; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.logs TO kbase_viewer;


--
-- Name: TABLE privileges; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.privileges TO kbase_viewer;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.refresh_tokens TO kbase_viewer;


--
-- Name: TABLE role_privileges; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.role_privileges TO kbase_viewer;


--
-- Name: TABLE roles; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.roles TO kbase_viewer;


--
-- Name: TABLE section_categories; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_categories TO kbase_viewer;


--
-- Name: TABLE section_dictionaries; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_dictionaries TO kbase_viewer;


--
-- Name: TABLE section_document_info_block_components_binary; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_document_info_block_components_binary TO kbase_viewer;


--
-- Name: TABLE section_document_info_block_components_number; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_document_info_block_components_number TO kbase_viewer;


--
-- Name: TABLE section_document_info_block_components_text; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_document_info_block_components_text TO kbase_viewer;


--
-- Name: TABLE section_document_info_block_headers; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_document_info_block_headers TO kbase_viewer;


--
-- Name: TABLE section_document_info_block_styles; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_document_info_block_styles TO kbase_viewer;


--
-- Name: TABLE section_document_info_block_type; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_document_info_block_type TO kbase_viewer;


--
-- Name: TABLE section_document_info_block_type_components; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_document_info_block_type_components TO kbase_viewer;


--
-- Name: TABLE section_documents; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_documents TO kbase_viewer;


--
-- Name: TABLE section_group_access; Type: ACL; Schema: kbase; Owner: postgres
--

GRANT SELECT ON TABLE kbase.section_group_access TO kbase_viewer;
GRANT ALL ON TABLE kbase.section_group_access TO kbase;


--
-- Name: TABLE section_types; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.section_types TO kbase_viewer;


--
-- Name: TABLE sections; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.sections TO kbase_viewer;


--
-- Name: SEQUENCE seq_section_group_access; Type: ACL; Schema: kbase; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE kbase.seq_section_group_access TO kbase;


--
-- Name: TABLE template_bodies; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.template_bodies TO kbase_viewer;


--
-- Name: TABLE template_color_themes; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.template_color_themes TO kbase_viewer;


--
-- Name: TABLE template_files; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.template_files TO kbase_viewer;


--
-- Name: TABLE templates; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.templates TO kbase_viewer;


--
-- Name: SEQUENCE seq_user_groups; Type: ACL; Schema: kbase; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE kbase.seq_user_groups TO kbase;


--
-- Name: TABLE settings; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.settings TO kbase_viewer;


--
-- Name: TABLE user_groups; Type: ACL; Schema: kbase; Owner: postgres
--

GRANT SELECT ON TABLE kbase.user_groups TO kbase_viewer;
GRANT ALL ON TABLE kbase.user_groups TO kbase;


--
-- Name: TABLE users; Type: ACL; Schema: kbase; Owner: kbase
--

GRANT SELECT ON TABLE kbase.users TO kbase_viewer;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: kbase; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA kbase GRANT SELECT ON TABLES TO kbase_viewer;


--
-- PostgreSQL database dump complete
--

\unrestrict OOjHtfBg1kN2IlPhiH7N8RIePUwCL6aHI9zRuDBQp2828CDR5fCwhbtk4cJdp4F

